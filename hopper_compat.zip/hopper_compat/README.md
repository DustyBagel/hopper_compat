Minetest Mod: hopper_compat

This is a mod that adds support for hoppers to work with other
containers/machines in other mods.

## License

This project is licensed under the MIT License. See the LICENSE file for details.

## Acknowledgments

This mod uses the api in the "hopper" mod by TenPlus1 and FaceDeer.